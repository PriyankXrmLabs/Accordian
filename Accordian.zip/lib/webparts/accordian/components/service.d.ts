export function addToList(context: any, listName: any, title: any, desc: any): Promise<void>;
export function getData(context: any, listName: any): Promise<any[] | undefined>;
//# sourceMappingURL=service.d.ts.map