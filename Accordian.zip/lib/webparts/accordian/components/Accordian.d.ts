import * as React from 'react';
import type { IAccordianProps } from './IAccordianProps';
interface IAccordianState {
    isFormVisible: boolean;
    newItemTitle: string;
    newItemDescription: string;
}
export default class Accordian extends React.Component<IAccordianProps, IAccordianState> {
    constructor(props: IAccordianProps);
    private handleAddItemClick;
    private handleDescriptionChange;
    private handleInputChange;
    private handleSubmit;
    render(): React.ReactElement<IAccordianProps>;
}
export {};
//# sourceMappingURL=Accordian.d.ts.map