export function Acc(props: any): JSX.Element;
//# sourceMappingURL=Acc.d.ts.map