declare const styles: {
    accordian: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
    button: string;
    form: string;
    richTextEditor: string;
};
export default styles;
//# sourceMappingURL=Accordian.module.scss.d.ts.map