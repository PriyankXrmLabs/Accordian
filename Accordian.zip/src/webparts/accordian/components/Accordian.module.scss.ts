/* tslint:disable */
require("./Accordian.module.css");
const styles = {
  accordian: 'accordian_b85f6262',
  teams: 'teams_b85f6262',
  welcome: 'welcome_b85f6262',
  welcomeImage: 'welcomeImage_b85f6262',
  links: 'links_b85f6262',
  button: 'button_b85f6262',
  form: 'form_b85f6262',
  richTextEditor: 'richTextEditor_b85f6262'
};

export default styles;
/* tslint:enable */